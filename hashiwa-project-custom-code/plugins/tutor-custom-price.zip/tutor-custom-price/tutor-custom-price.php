<?php

/**
 * Plugin Name: Tutor LMS Custom Topic Price Override
 * Description: Override harga checkout Tutor LMS berdasarkan tabel tutor_topic_price.
 * Version: 1.0
 */

add_filter('tutor_before_create_order', function ($order_data) {
    if (empty($order_data['items'])) return $order_data;

    global $wpdb;
    $table = "{$wpdb->prefix}tutor_topic_price";

    $new_total = 0;

    foreach ($order_data['items'] as $key => $item) {
        $course_id = $item['item_id'];

        // Ambil MIN harga topic
        $price = $wpdb->get_var($wpdb->prepare(
            "SELECT MIN(price) FROM $table WHERE course_id = %d",
            $course_id
        ));

        if (!$price) continue;

        // Override harga
        $order_data['items'][$key]['regular_price'] = $price;
        $order_data['items'][$key]['sale_price'] = $price;
        $order_data['items'][$key]['discount_price'] = $price;
        $order_data['items'][$key]['display_price'] = $price;

        $new_total += $price;
    }

    // Update subtotal & total order
    $order_data['subtotal_price'] = $new_total;
    $order_data['total_price'] = $new_total;

    return $order_data;
});
