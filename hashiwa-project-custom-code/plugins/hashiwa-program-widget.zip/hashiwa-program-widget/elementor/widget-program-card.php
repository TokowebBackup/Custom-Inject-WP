<?php
if (!defined('ABSPATH')) exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class Hashiwa_Program_Card_Widget extends Widget_Base
{

    public function get_name()
    {
        return 'hashiwa_program_card';
    }

    public function get_title()
    {
        return 'Hashiwa Program Card';
    }

    public function get_icon()
    {
        return 'eicon-post-list';
    }

    public function get_categories()
    {
        return ['hashiwa-category'];
    }

    protected function register_controls()
    {

        // FILTER SECTION
        $this->start_controls_section(
            'filter_section',
            ['label' => 'Filter Program']
        );

        $terms = get_terms(['taxonomy' => 'jenis_program', 'hide_empty' => false]);
        $options = ['all' => 'Semua Jenis Program'];
        foreach ($terms as $term) {
            $options[$term->slug] = $term->name;
        }

        $this->add_control(
            'filter_jenis',
            [
                'label' => 'Jenis Program',
                'type' => Controls_Manager::SELECT,
                'default' => 'all',
                'options' => $options
            ]
        );

        $this->add_control(
            'jumlah',
            [
                'label' => 'Jumlah Program',
                'type' => Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 20,
            ]
        );

        $this->add_control(
            'show_rating',
            [
                'label' => 'Tampilkan Rating',
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {

        $settings = $this->get_settings_for_display();

        // Query
        $args = [
            'post_type'      => 'program',
            'posts_per_page' => $settings['jumlah'],
            'orderby'        => 'menu_order',
            'order'          => 'ASC'
        ];

        if ($settings['filter_jenis'] !== 'all') {
            $args['tax_query'] = [[
                'taxonomy' => 'jenis_program',
                'field'    => 'slug',
                'terms'    => $settings['filter_jenis']
            ]];
        }

        $programs = new WP_Query($args);

        echo '<div class="hashiwa-program-grid">';

        while ($programs->have_posts()) : $programs->the_post();

            $thumb = get_the_post_thumbnail_url(get_the_ID(), 'medium');
            $excerpt = wp_trim_words(get_the_excerpt(), 15);

            $durasi = get_field('durasi_program', get_the_ID());
            $rating = get_field('rating_program', get_the_ID());
            $cta_text = get_field('button_text', get_the_ID()) ?: 'Lihat Program';
            $cta_url = get_field('button_url', get_the_ID()) ?: get_permalink();
            $highlight = get_field('highlight_program', get_the_ID());

            $terms = get_the_terms(get_the_ID(), 'jenis_program');
            $badge = $terms ? $terms[0]->name : '';

            echo '<div class="program-card">';

            // highlight
            if ($highlight) {
                echo '<div class="highlight-badge">Unggulan</div>';
            }

            // thumbnail
            if ($thumb) {
                echo '<div class="pc-thumb"><img src="' . $thumb . '" alt=""></div>';
            }

            echo '<div class="pc-content">';

            // badge kategori
            echo '<span class="pc-badge">' . $badge . '</span>';

            // title
            echo '<h3 class="pc-title">' . get_the_title() . '</h3>';

            // excerpt
            echo '<p class="pc-desc">' . $excerpt . '</p>';

            // durasi
            if ($durasi) {
                echo '<div class="pc-durasi"><i class="eicon-clock"></i> ' . $durasi . '</div>';
            }

            // rating
            if ($settings['show_rating'] === 'yes' && $rating) {
                echo '<div class="pc-rating">';
                for ($i = 1; $i <= 5; $i++) {
                    echo ($i <= $rating)
                        ? '<span class="star full">★</span>'
                        : '<span class="star empty">☆</span>';
                }
                echo '</div>';
            }

            // CTA
            echo '<a href="' . $cta_url . '" class="pc-btn">' . $cta_text . '</a>';

            echo '</div></div>';

        endwhile;
        wp_reset_postdata();

        echo '</div>';

        // Inline style
?>
        <style>
            .hashiwa-program-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 30px;
            }

            .program-card {
                background: #fff;
                border-radius: 14px;
                overflow: hidden;
                box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
                transition: 0.25s ease;
                position: relative;
            }

            .program-card:hover {
                transform: translateY(-6px);
                box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
            }

            .highlight-badge {
                position: absolute;
                top: 12px;
                right: 12px;
                background: #FAD035;
                padding: 6px 12px;
                font-weight: 600;
                border-radius: 8px;
                font-size: 12px;
            }

            .pc-thumb img {
                width: 100%;
                height: 180px;
                object-fit: cover;
            }

            .pc-content {
                padding: 20px;
            }

            .pc-badge {
                background: #EFEFF5;
                padding: 5px 10px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 600;
                display: inline-block;
                margin-bottom: 10px;
            }

            .pc-title {
                font-size: 20px;
                margin-bottom: 10px;
                font-weight: 700;
            }

            .pc-desc {
                font-size: 14px;
                color: #666;
                margin-bottom: 15px;
            }

            .pc-durasi {
                font-size: 14px;
                margin-bottom: 10px;
                font-weight: 600;
            }

            .pc-rating {
                margin-bottom: 15px;
                font-size: 18px;
                color: #F6B100;
            }

            .pc-rating .star.empty {
                color: #ddd;
            }

            .pc-btn {
                display: inline-block;
                width: 100%;
                text-align: center;
                padding: 12px;
                background: #FAD035;
                border-radius: 10px;
                font-weight: 700;
                color: #000;
                text-decoration: none;
            }

            .pc-btn:hover {
                background: #f7c820;
            }
        </style>
<?php
    }
}
